//
//  GBParagraphExampleItem.m
//  appledoc
//
//  Created by Tomaz Kragelj on 2.9.10.
//  Copyright (C) 2010, Gentle Bytes. All rights reserved.
//

#import "GBParagraphExampleItem.h"

@implementation GBParagraphExampleItem

@end
